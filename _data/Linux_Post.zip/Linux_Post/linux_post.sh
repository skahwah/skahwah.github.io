echo "Collecting Information "
echo " "
echo "Files"
echo " "
echo "[*] resolv.conf"
cat /etc/resolv.conf
echo " "
echo "[*] motd"
cat /etc/motd
echo " "
echo "[*] issue"
cat /etc/issue
echo " "
echo "[*] passwd"
cat /etc/passwd
echo " "
echo "[*] shadow"
cat /etc/shadow
echo " "
echo "[*] ssh id"
cat /root/.sshd/id
echo " "
echo "System"
echo " "
echo "[*] uname"
uname -a
echo " "
echo "[*] ps aux"
ps aux
echo " "
echo "[*] w"
w
echo " "
echo "[*] mysql version"
mysql --version
echo " "
echo "[*] mount"
mount
echo " "
echo "[*] crontab"
/usr/bin/crontab -l
echo " "
echo "[*] last -a"
last -a
echo " "
echo "[*] lastlog"
lastlog
echo " "
echo "Networking "
echo " "
echo "[*] hostname -f"
hostname -f
hostname
echo " "
echo "[*] ip ro show"
ip ro show
echo " "
echo "[*] interfaces"
cat /network/interfaces
echo " "
echo "[*] iptables 1"
iptables -L -n -v
echo " "
echo "[*] iptables 2"
iptables -t nat -L -n -v
echo " "
echo "[*] netstat antup"
netstat -antup
echo " "
echo "[*] arp -a"
arp -a
echo " "
echo "[*] lsof"
lsof -nPi
echo " "
echo "Finding Files"
echo " "
echo "[*] updatedb"
echo "Wait..."
updatedb
echo "Done..."
echo " "
echo "[*] Tar "
locate tar | grep [.]tar$
echo " "
echo "[*] Tgz"
locate tgz | grep [.]tgz$
echo " "
echo "[*] SQL"
locate sql | grep [.]sql$
echo " "
echo "[*] PHP"
locate config.inc | grep [.]php$
echo " "
echo "[*] properties"
ls /home//id .properties | grep [.]properties #
echo " "
echo "[*] XML"
locate .xml | grep [.]xml # java/.net config files
echo " "
echo "[*] TXT"
find / -name *.txt
echo " "
echo "[*] DOC"
find / -name *.doc
echo " "
echo "[*] XLS"
find / -name *.xls
echo " "
echo "[*] CSV"
find / -name *.csv
echo " "
echo "[*] PDF"
find / -name *.pdf
echo " "
echo "[*] MOAR ACCESS!"
find / -name network-secret.txt
